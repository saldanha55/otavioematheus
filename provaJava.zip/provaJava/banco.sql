-- --------------------------------------------------------
-- Servidor:                     127.0.0.1
-- Versão do servidor:           8.0.41 - MySQL Community Server - GPL
-- OS do Servidor:               Win64
-- HeidiSQL Versão:              12.10.0.7000
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- Copiando estrutura do banco de dados para pj_hospital_otavio_matheus
CREATE DATABASE IF NOT EXISTS `pj_hospital_otavio_matheus` /*!40100 DEFAULT CHARACTER SET utf8mb3 */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `pj_hospital_otavio_matheus`;

-- Copiando estrutura para tabela pj_hospital_otavio_matheus.atendimento
CREATE TABLE IF NOT EXISTS `atendimento` (
  `id` int NOT NULL AUTO_INCREMENT,
  `Funcionario_idFuncionario` int NOT NULL,
  `Paciente_idPaciente` int NOT NULL,
  `data` varchar(45) NOT NULL,
  PRIMARY KEY (`id`,`Funcionario_idFuncionario`,`Paciente_idPaciente`),
  KEY `fk_Funcionario_has_Paciente_Paciente1_idx` (`Paciente_idPaciente`),
  KEY `fk_Funcionario_has_Paciente_Funcionario1_idx` (`Funcionario_idFuncionario`),
  CONSTRAINT `fk_Funcionario_has_Paciente_Funcionario1` FOREIGN KEY (`Funcionario_idFuncionario`) REFERENCES `funcionario` (`id`),
  CONSTRAINT `fk_Funcionario_has_Paciente_Paciente1` FOREIGN KEY (`Paciente_idPaciente`) REFERENCES `paciente` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- Copiando dados para a tabela pj_hospital_otavio_matheus.atendimento: ~0 rows (aproximadamente)

-- Copiando estrutura para tabela pj_hospital_otavio_matheus.funcionario
CREATE TABLE IF NOT EXISTS `funcionario` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nome` varchar(45) NOT NULL,
  `periodoTrabalho` varchar(45) NOT NULL,
  `cpf` varchar(45) DEFAULT NULL,
  `numero` varchar(45) DEFAULT NULL,
  `endereco` varchar(45) DEFAULT NULL,
  `setor_idSetor` int NOT NULL,
  PRIMARY KEY (`id`,`setor_idSetor`),
  KEY `fk_funcionario_setor1_idx` (`setor_idSetor`),
  CONSTRAINT `fk_funcionario_setor1` FOREIGN KEY (`setor_idSetor`) REFERENCES `setor` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- Copiando dados para a tabela pj_hospital_otavio_matheus.funcionario: ~0 rows (aproximadamente)

-- Copiando estrutura para tabela pj_hospital_otavio_matheus.internacao
CREATE TABLE IF NOT EXISTS `internacao` (
  `id` int NOT NULL,
  `dataInternacao` varchar(45) NOT NULL,
  `dataSaida` varchar(45) DEFAULT NULL,
  `paciente_idPaciente` int NOT NULL,
  `funcionario_idFuncionario` int NOT NULL,
  `local_idQuarto` int NOT NULL,
  PRIMARY KEY (`id`,`paciente_idPaciente`,`funcionario_idFuncionario`,`local_idQuarto`),
  KEY `fk_internacao_paciente1_idx` (`paciente_idPaciente`),
  KEY `fk_internacao_funcionario1_idx` (`funcionario_idFuncionario`),
  KEY `fk_internacao_local1_idx` (`local_idQuarto`),
  CONSTRAINT `fk_internacao_funcionario1` FOREIGN KEY (`funcionario_idFuncionario`) REFERENCES `funcionario` (`id`),
  CONSTRAINT `fk_internacao_local1` FOREIGN KEY (`local_idQuarto`) REFERENCES `quarto` (`id`),
  CONSTRAINT `fk_internacao_paciente1` FOREIGN KEY (`paciente_idPaciente`) REFERENCES `paciente` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- Copiando dados para a tabela pj_hospital_otavio_matheus.internacao: ~0 rows (aproximadamente)

-- Copiando estrutura para tabela pj_hospital_otavio_matheus.medicamento
CREATE TABLE IF NOT EXISTS `medicamento` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nome` varchar(45) NOT NULL,
  `quantidade` int NOT NULL,
  `preco` decimal(7,2) DEFAULT NULL,
  `desc` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb3;

-- Copiando dados para a tabela pj_hospital_otavio_matheus.medicamento: ~0 rows (aproximadamente)
INSERT INTO `medicamento` (`id`, `nome`, `quantidade`, `preco`, `desc`) VALUES
	(2, 'sad', 253, 424.24, 'asda');

-- Copiando estrutura para tabela pj_hospital_otavio_matheus.paciente
CREATE TABLE IF NOT EXISTS `paciente` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nome` varchar(45) NOT NULL,
  `rg` varchar(45) DEFAULT NULL,
  `cpf` varchar(45) DEFAULT NULL,
  `dataNascimento` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb3;

-- Copiando dados para a tabela pj_hospital_otavio_matheus.paciente: ~0 rows (aproximadamente)

-- Copiando estrutura para tabela pj_hospital_otavio_matheus.procedimento
CREATE TABLE IF NOT EXISTS `procedimento` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nome` varchar(100) NOT NULL,
  `desc` varchar(450) DEFAULT NULL,
  `preco` decimal(7,2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3;

-- Copiando dados para a tabela pj_hospital_otavio_matheus.procedimento: ~0 rows (aproximadamente)

-- Copiando estrutura para tabela pj_hospital_otavio_matheus.quarto
CREATE TABLE IF NOT EXISTS `quarto` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nome` varchar(45) DEFAULT NULL,
  `preco` decimal(7,2) DEFAULT NULL,
  `andar` varchar(45) DEFAULT NULL,
  `plano` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3;

-- Copiando dados para a tabela pj_hospital_otavio_matheus.quarto: ~0 rows (aproximadamente)

-- Copiando estrutura para tabela pj_hospital_otavio_matheus.setor
CREATE TABLE IF NOT EXISTS `setor` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nome` varchar(45) NOT NULL,
  `ref` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3;

-- Copiando dados para a tabela pj_hospital_otavio_matheus.setor: ~0 rows (aproximadamente)

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
